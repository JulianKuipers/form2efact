function main() {
    var poNum = document.getElementById("poNumber").value;
    var invCount = document.getElementById("invoiceCount").value;;
    var xml = getXML();
    var name = "FEA" + poNum + invCount + ".xml";
    console.log(`Gen activated: ${poNum}, ${invCount}; ${name}`);
    console.log(xml);
    createXML(xml, name);
}