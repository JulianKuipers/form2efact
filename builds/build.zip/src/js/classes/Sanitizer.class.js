class Sanitizer {

    #possibleTypes = ["text"];
    #type = null;

    constructor(type) {
        if (this.#possibleTypes.includes(type)) {
            this.#type = type;
        }
    }

    sanitize(value) {
        switch (this.#type) {
            case "text":
                return this._SanitizeText(value);
                break;
        
            default:
                break;
        }
    }

    _SanitizeText(text) {
        let escapeTokens = [
            {"token": "&", "escaped": "&amp;"},
            {"token": '"', "escaped": "&quot;"},
            {"token": "'", "escaped": "&apos;"}
        ];
        let sanitizedText = text;
        for (const tokenObj of escapeTokens) {
            sanitizedText = sanitizedText.replaceAll(tokenObj.token, tokenObj.escaped);
        }
        return sanitizedText;
    }

}