class Sanitizer {

    // Private fields
    #types = ["text"];
    #type;
    
    constructor(type) {
        if (this.#types.includes(type)) {
            this.#type = type;
            console.log(`Type ${this.#type} is a valid type.`);
        } else {
            this.type = undefined;
            let err = `Type ${this.#type} is not a valid type!`;
            console.error(err);
            return err;
        }
        
    }

    sanitize(value) {
        let newVal;
        switch (this.#type) {
            case "text":
                newVal = this._textSanitizer(value);
                break;
        
            default:
                break;
        }
        return newVal;
    }

    _textSanitizer(text) {
        text.replace("&", "&amp;");
        text.replace("<", "&lt;");
        text.replace(">", "&gt;");
        return text;
    }


}